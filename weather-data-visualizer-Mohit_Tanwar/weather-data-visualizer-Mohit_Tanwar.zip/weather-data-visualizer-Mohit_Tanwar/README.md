# Weather Data Visualizer — Your Name

## 📌 Overview
This project analyzes real weather data using Python (Pandas, NumPy, Matplotlib).

## 🧾 Dataset
- Source: raw_weather.csv
- Columns: date, meantemp, humidity, wind_speed, meanpressure

## 🔧 Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib

## 📊 Features
- Data cleaning
- Statistical analysis
- Monthly aggregation
- Multiple visualizations
- CSV exports

## 📂 Outputs
- Cleaned dataset: `data/weather_cleaned.csv`
- Monthly stats: `data/monthly_stats.csv`
- Yearly stats: `data/yearly_stats.csv`
- Plots: Stored in `images/`

## ▶️ How to Run
```bash
python main.py