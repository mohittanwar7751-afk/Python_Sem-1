import matplotlib.pyplot as plt

import pandas as pd

# -----------------------------
# Task 1 & 2: Load and Clean
# -----------------------------

# Load dataset
df = pd.read_csv("data/raw_weather.csv")

# Convert date column to datetime
df['date'] = pd.to_datetime(df['date'])

# Drop missing values
df = df.dropna()

# Keep only needed columns
df = df[['date', 'meantemp', 'humidity', 'wind_speed', 'meanpressure']]

# Extract month and year
df['month'] = df['date'].dt.month
df['year'] = df['date'].dt.year

# Save cleaned CSV
df.to_csv("data/weather_cleaned.csv", index=False)

print("\n===== INFO AFTER CLEANING =====")
print(df.info())

# -----------------------------
# Task 3: Statistical Analysis
# -----------------------------

print("\n===== STATISTICS =====")

print("Mean temperature:", df['meantemp'].mean())
print("Max humidity:", df['humidity'].max())
print("Min wind speed:", df['wind_speed'].min())
print("Std deviation temp:", df['meantemp'].std())

# -----------------------------
# Task 4: Visualizations
# -----------------------------

# 1) Line chart for daily temperature trend
plt.figure(figsize=(10, 5))
plt.plot(df['date'], df['meantemp'])
plt.title("Daily Mean Temperature")
plt.xlabel("Date")
plt.ylabel("Mean Temperature (°C)")
plt.tight_layout()
plt.savefig("images/daily_temperature_line.png")
plt.close()

# 2) Bar chart for monthly average temperature
monthly_temp = df.groupby('month')['meantemp'].mean()

plt.figure(figsize=(8, 5))
plt.bar(monthly_temp.index, monthly_temp.values)
plt.title("Monthly Average Temperature")
plt.xlabel("Month (1-12)")
plt.ylabel("Mean Temperature (°C)")
plt.tight_layout()
plt.savefig("images/monthly_temperature_bar.png")
plt.close()

# 3) Scatter plot: humidity vs temperature
plt.figure(figsize=(6, 5))
plt.scatter(df['meantemp'], df['humidity'])
plt.title("Humidity vs Temperature")
plt.xlabel("Mean Temperature (°C)")
plt.ylabel("Humidity (%)")
plt.tight_layout()
plt.savefig("images/humidity_vs_temperature_scatter.png")
plt.close()

# 4) Combined figure with two subplots (bonus + requirement)
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

ax1.plot(df['date'], df['meantemp'])
ax1.set_title("Daily Mean Temperature")
ax1.set_ylabel("Temp (°C)")

ax2.plot(df['date'], df['humidity'])
ax2.set_title("Daily Humidity")
ax2.set_xlabel("Date")
ax2.set_ylabel("Humidity (%)")

plt.tight_layout()
plt.savefig("images/temp_and_humidity_subplots.png")
plt.close()

print("\nAll plots saved in the 'images' folder.")

# -----------------------------
# Task 5: Grouping & Aggregation
# -----------------------------

# Monthly average statistics
monthly_stats = df.groupby('month').agg({
    'meantemp': 'mean',
    'humidity': 'mean',
    'wind_speed': 'mean',
    'meanpressure': 'mean'
})

print("\n===== MONTHLY STATS =====")
print(monthly_stats)

# Yearly average statistics (if multiple years present)
yearly_stats = df.groupby('year').agg({
    'meantemp': 'mean',
    'humidity': 'mean',
    'wind_speed': 'mean',
    'meanpressure': 'mean'
})

print("\n===== YEARLY STATS =====")
print(yearly_stats)

# Save grouped data
monthly_stats.to_csv("data/monthly_stats.csv")
yearly_stats.to_csv("data/yearly_stats.csv")

print("\nGrouped data saved in /data folder (monthly_stats.csv, yearly_stats.csv)")