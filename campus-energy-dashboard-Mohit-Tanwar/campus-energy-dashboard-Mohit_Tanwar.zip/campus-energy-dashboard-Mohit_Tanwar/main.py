import os
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# ==============================
# Task 1: Data Ingestion & Validation
# ==============================

def load_energy_data(data_dir="data"):
    """
    Reads all CSV files in data_dir, adds building_name column, 
    merges into a single DataFrame and returns it.
    """
    data_path = Path(data_dir)
    all_files = list(data_path.glob("*.csv"))

    if not all_files:
        print("[ERROR] No CSV files found in /data folder.")
        return pd.DataFrame()

    df_list = []
    error_log = []

    for file in all_files:
        try:
            # building name from filename (admin_block.csv -> admin_block)
            building_name = file.stem

            print(f"[INFO] Loading file: {file.name}")
            df = pd.read_csv(file)

            # Basic validation
            if "timestamp" not in df.columns or "kwh" not in df.columns:
                print(f"[WARNING] {file.name} skipped: missing 'timestamp' or 'kwh' column.")
                error_log.append(f"{file.name}: Missing required columns.")
                continue

            # Parse timestamp
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df = df.dropna(subset=["timestamp", "kwh"])

            # Add building metadata
            df["building_name"] = building_name

            df_list.append(df)

        except FileNotFoundError:
            msg = f"{file.name}: File not found."
            print("[ERROR]", msg)
            error_log.append(msg)

        except Exception as e:
            msg = f"{file.name}: Error loading file -> {e}"
            print("[ERROR]", msg)
            error_log.append(msg)

    if not df_list:
        print("[ERROR] No valid data loaded.")
        return pd.DataFrame()

    df_combined = pd.concat(df_list, ignore_index=True)
    df_combined = df_combined.sort_values("timestamp")

    print("\n[INFO] Combined DataFrame created.")
    print(df_combined.head())

    # Save cleaned/combined data for Task 5
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    df_combined.to_csv(output_dir / "cleaned_energy_data.csv", index=False)
    print("[INFO] Saved cleaned data to output/cleaned_energy_data.csv")

    # Log errors if any
    if error_log:
        with open(output_dir / "error_log.txt", "w") as f:
            f.write("\n".join(error_log))
        print("[INFO] Error log saved to output/error_log.txt")

    return df_combined


# ==============================
# Task 2: Core Aggregation Logic
# ==============================

def calculate_daily_totals(df):
    """
    Returns daily total kWh per building.
    """
    df = df.set_index("timestamp")
    daily = df.groupby("building_name").resample("D")["kwh"].sum().reset_index()
    return daily


def calculate_weekly_aggregates(df):
    """
    Returns weekly total kWh per building.
    """
    df = df.set_index("timestamp")
    weekly = df.groupby("building_name").resample("W")["kwh"].sum().reset_index()
    return weekly


def building_wise_summary(df):
    """
    Returns building-wise summary: mean, min, max, total kWh.
    """
    summary = df.groupby("building_name")["kwh"].agg(
        mean_kwh="mean",
        min_kwh="min",
        max_kwh="max",
        total_kwh="sum"
    ).reset_index()

    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    summary.to_csv(output_dir / "building_summary.csv", index=False)
    print("[INFO] Saved building summary to output/building_summary.csv")

    return summary


# ==============================
# Task 3: Object-Oriented Modeling
# ==============================

class MeterReading:
    def __init__(self, timestamp, kwh):
        self.timestamp = timestamp
        self.kwh = kwh


class Building:
    def __init__(self, name):
        self.name = name
        self.meter_readings = []

    def add_reading(self, reading: MeterReading):
        self.meter_readings.append(reading)

    def calculate_total_consumption(self):
        return sum(r.kwh for r in self.meter_readings)

    def generate_report(self):
        if not self.meter_readings:
            return f"Building {self.name}: No data available."

        total = self.calculate_total_consumption()
        kwh_values = [r.kwh for r in self.meter_readings]
        avg = sum(kwh_values) / len(kwh_values)
        min_kwh = min(kwh_values)
        max_kwh = max(kwh_values)

        report = (
            f"Report for Building: {self.name}\n"
            f"Total Consumption: {total:.2f} kWh\n"
            f"Average Reading: {avg:.2f} kWh\n"
            f"Minimum Reading: {min_kwh:.2f} kWh\n"
            f"Maximum Reading: {max_kwh:.2f} kWh\n"
        )
        return report


class BuildingManager:
    def __init__(self):
        self.buildings = {}

    def get_or_create_building(self, name):
        if name not in self.buildings:
            self.buildings[name] = Building(name)
        return self.buildings[name]

    def load_from_dataframe(self, df):
        for _, row in df.iterrows():
            b_name = row["building_name"]
            ts = row["timestamp"]
            kwh = row["kwh"]
            building = self.get_or_create_building(b_name)
            building.add_reading(MeterReading(ts, kwh))

    def generate_all_reports(self):
        reports = []
        for building in self.buildings.values():
            reports.append(building.generate_report())
        return "\n".join(reports)


# ==============================
# Task 4: Visual Output with Matplotlib
# ==============================

def create_dashboard_plots(df, daily_totals, weekly_totals):
    """
    Creates:
    1. Trend line – daily consumption over time for all buildings
    2. Bar chart – average weekly usage across buildings
    3. Scatter plot – peak-hour consumption vs time (simple approximation)
    Saves as output/dashboard.png
    """
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)

    fig, axes = plt.subplots(3, 1, figsize=(10, 15))
    fig.suptitle("Campus Energy-Use Dashboard", fontsize=16)

    # 1) Trend Line – daily consumption over time for all buildings
    ax1 = axes[0]
    for building in daily_totals["building_name"].unique():
        bdf = daily_totals[daily_totals["building_name"] == building]
        ax1.plot(bdf["timestamp"], bdf["kwh"], marker="o", label=building)

    ax1.set_title("Daily Total Consumption")
    ax1.set_xlabel("Date")
    ax1.set_ylabel("kWh")
    ax1.legend()
    ax1.grid(True)

    # 2) Bar Chart – compare average weekly usage across buildings
    ax2 = axes[1]
    weekly_avg = weekly_totals.groupby("building_name")["kwh"].mean().reset_index()
    ax2.bar(weekly_avg["building_name"], weekly_avg["kwh"])
    ax2.set_title("Average Weekly Consumption per Building")
    ax2.set_xlabel("Building")
    ax2.set_ylabel("Average Weekly kWh")

    # 3) Scatter Plot – peak-hour consumption vs. time/building
    ax3 = axes[2]
    # Let's approximate "peak hour" as the maximum kwh per building
    # (with timestamp of that max)
    peak_rows = df.loc[df.groupby("building_name")["kwh"].idxmax()]
    ax3.scatter(peak_rows["timestamp"], peak_rows["kwh"])
    for _, row in peak_rows.iterrows():
        ax3.annotate(row["building_name"], (row["timestamp"], row["kwh"]))

    ax3.set_title("Peak Consumption Points")
    ax3.set_xlabel("Timestamp")
    ax3.set_ylabel("kWh")
    ax3.grid(True)

    plt.tight_layout(rect=[0, 0.03, 1, 0.97])
    dashboard_path = output_dir / "dashboard.png"
    plt.savefig(dashboard_path)
    plt.close(fig)
    print(f"[INFO] Dashboard saved to {dashboard_path}")


# ==============================
# Task 5: Persistence & Executive Summary
# ==============================

def generate_summary_text(df, building_summary, daily_totals, weekly_totals):
    """
    Creates a summary.txt with:
    - Total campus consumption
    - Highest-consuming building
    - Peak load time
    - Weekly/daily trends
    """
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)

    total_campus_consumption = df["kwh"].sum()

    # Highest consuming building
    max_building_row = building_summary.loc[building_summary["total_kwh"].idxmax()]
    highest_building = max_building_row["building_name"]
    highest_building_kwh = max_building_row["total_kwh"]

    # Peak load time (max single reading)
    peak_row = df.loc[df["kwh"].idxmax()]
    peak_time = peak_row["timestamp"]
    peak_kwh = peak_row["kwh"]
    peak_building = peak_row["building_name"]

    # Simple daily & weekly trends description
    daily_avg = daily_totals["kwh"].mean()
    weekly_avg = weekly_totals["kwh"].mean()

    summary_lines = [
        "CAMPUS ENERGY CONSUMPTION SUMMARY",
        "================================",
        f"Total campus consumption: {total_campus_consumption:.2f} kWh",
        "",
        f"Highest-consuming building: {highest_building} ({highest_building_kwh:.2f} kWh)",
        "",
        "Peak Load Details:",
        f"- Building: {peak_building}",
        f"- Time: {peak_time}",
        f"- Consumption at peak: {peak_kwh:.2f} kWh",
        "",
        "Trends:",
        f"- Average daily consumption (all buildings): {daily_avg:.2f} kWh",
        f"- Average weekly consumption (all buildings): {weekly_avg:.2f} kWh",
        "",
        "Insights:",
        "- Use this information to identify buildings where energy-saving measures",
        "  like efficient lighting or AC scheduling can have the most impact."
    ]

    summary_text = "\n".join(summary_lines)

    with open(output_dir / "summary.txt", "w") as f:
        f.write(summary_text)

    print("[INFO] summary.txt generated in output/summary.txt")
    print("\n----- EXECUTIVE SUMMARY (also saved to file) -----\n")
    print(summary_text)


# ==============================
# MAIN SCRIPT – Run All Tasks
# ==============================

def main():
    print("==== Campus Energy Dashboard – Capstone Project ====\n")

    # Task 1: Load and validate data
    df = load_energy_data("data")
    if df.empty:
        print("[FATAL] No data to process. Exiting.")
        return

    # Task 2: Aggregations
    daily_totals = calculate_daily_totals(df)
    weekly_totals = calculate_weekly_aggregates(df)
    building_summary = building_wise_summary(df)

    # Task 3: Object-Oriented modeling
    manager = BuildingManager()
    manager.load_from_dataframe(df)
    all_reports = manager.generate_all_reports()
    print("\n===== BUILDING REPORTS (OOP) =====\n")
    print(all_reports)

    # Task 4: Visual dashboard
    create_dashboard_plots(df, daily_totals, weekly_totals)

    # Task 5: Summary report
    generate_summary_text(df, building_summary, daily_totals, weekly_totals)


if __name__ == "__main__":
    main()