# Library Inventory Manager

A simple command-line based library inventory manager for tracking books in a campus library.

## 👤 Author
Mohit Tanwar

## 📌 Features
- Add new books
- Issue and return books
- Search books by title or ISBN
- Save data to JSON file
- Logging of actions to `library.log`

## 🗂 Project Structure

library-inventory-manager-Mohit_Tanwar/
├─ library_manager/
│  ├─ book.py
│  ├─ inventory.py
├─ cli/
│  ├─ main.py
├─ data/
│  ├─ books.json
├─ library.log
├─ README.md
├─ requirements.txt
└─ .gitignore

## ▶️ Usage

### Run application
```bash
python -m cli.main

Add a book
	•	Choose 1 and enter details

Issue/Return book
	•	Choose 2 or 3

View all
	•	Choose 4

Search
	•	Choose 5

🧰 Requirements
	•	Python 3.8+
	•	pathlib
	•	json

💾 Data Storage

All data is stored inside:
data/books.json

🪵 Logging

Application logs stored in:
library.log

📌 Make sure you save README.md.

---

# 🟦 STEP 4 — Create `.gitignore`

You already have `.gitignore`. Make sure it includes:
pycache/
*.pyc
*.pyo
*.log
.venv/

This avoids unnecessary files in GitHub.

---

# 🟦 STEP 5 — Requirements.txt

Open `requirements.txt` and write:



(Everything else is built-in, so teacher just wants a file.)

---

# 🟦 STEP 6 — GIT Initial Commit

Open terminal in project root and run:

```bash
git init
git add .
git commit -m "Initial library inventory manager project"