import logging

from library_manager.inventory import LibraryInventory


def setup_logging():
    logging.basicConfig(
        filename="library.log",          # log file name
        level=logging.INFO,             # log level
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

def print_menu():
    print("\n==== Library Inventory Manager ====")
    print("1. Add Book")
    print("2. Issue Book")
    print("3. Return Book")
    print("4. View All Books")
    print("5. Search Book")
    print("6. Exit")


def handle_add_book(inventory):
    try:
        title = input("Enter book title: ").strip()
        author = input("Enter author name: ").strip()
        isbn = input("Enter ISBN: ").strip()

        if not title or not author or not isbn:
            print("All fields are required.")
            return

        if inventory.add_book(title, author, isbn):
            print("Book added successfully!")
        else:
            print("Book with this ISBN already exists.")
    except Exception as e:
        print("Error while adding book.")
        logging.error(f"Error in handle_add_book: {e}")


def handle_issue_book(inventory):
    try:
        isbn = input("Enter ISBN of book to issue: ").strip()
        book, msg = inventory.issue_book(isbn)
        print(msg)
        if book:
            print(book)
    except Exception as e:
        print("Error while issuing book.")
        logging.error(f"Error in handle_issue_book: {e}")


def handle_return_book(inventory):
    try:
        isbn = input("Enter ISBN of book to return: ").strip()
        book, msg = inventory.return_book(isbn)
        print(msg)
        if book:
            print(book)
    except Exception as e:
        print("Error while returning book.")
        logging.error(f"Error in handle_return_book: {e}")


def handle_view_all(inventory):
    try:
        books = inventory.display_all()
        if not books:
            print("No books in the catalog.")
            return
        for book in books:
            print(book)
    except Exception as e:
        print("Error while viewing books.")
        logging.error(f"Error in handle_view_all: {e}")


def handle_search(inventory):
    try:
        print("Search by:")
        print("1. Title")
        print("2. ISBN")
        choice = input("Enter choice: ").strip()

        if choice == "1":
            title = input("Enter title to search: ").strip()
            results = inventory.search_by_title(title)
            if results:
                for book in results:
                    print(book)
            else:
                print("No books found with that title.")
        elif choice == "2":
            isbn = input("Enter ISBN to search: ").strip()
            book = inventory.search_by_isbn(isbn)
            if book:
                print(book)
            else:
                print("No book found with that ISBN.")
        else:
            print("Invalid choice.")
    except Exception as e:
        print("Error while searching books.")
        logging.error(f"Error in handle_search: {e}")

def main():
    setup_logging()
    logging.info("Application started.")

    inventory = LibraryInventory()

    while True:
        print_menu()
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            handle_add_book(inventory)
        elif choice == "2":
            handle_issue_book(inventory)
        elif choice == "3":
            handle_return_book(inventory)
        elif choice == "4":
            handle_view_all(inventory)
        elif choice == "5":
            handle_search(inventory)
        elif choice == "6":
            print("Exiting... Goodbye!")
            logging.info("Application exited by user.")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 6.")


if __name__ == "__main__":
    main()