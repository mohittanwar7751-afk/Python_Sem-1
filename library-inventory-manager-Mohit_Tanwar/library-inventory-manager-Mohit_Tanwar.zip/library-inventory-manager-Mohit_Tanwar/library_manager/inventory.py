import json
import logging
from pathlib import Path

from .book import Book  # relative import


class LibraryInventory:
    def __init__(self, data_file="data/books.json"):
        self.books = []
        self.data_file = Path(data_file)
        self.load_from_file()

    # ---------- File operations ----------
    def load_from_file(self):
        try:
            if not self.data_file.exists():
                logging.info("Data file not found. Starting with an empty catalog.")
                self.books = []
                return

            with self.data_file.open("r", encoding="utf-8") as f:
                data = json.load(f)

            self.books = [Book(**book_dict) for book_dict in data]
            logging.info("Catalog loaded successfully.")

        except json.JSONDecodeError:
            logging.error("JSON file is corrupted. Starting with an empty catalog.")
            self.books = []
        except Exception as e:
            logging.error(f"Error loading catalog: {e}")
            self.books = []

    def save_to_file(self):
        try:
            # Ensure parent folder exists
            self.data_file.parent.mkdir(parents=True, exist_ok=True)

            data = [book.to_dict() for book in self.books]
            with self.data_file.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)

            logging.info("Catalog saved successfully.")
        except Exception as e:
            logging.error(f"Error saving catalog: {e}")

    # ---------- Basic Operations ----------
    def add_book(self, title, author, isbn):
        # simple check: avoid duplicate ISBN
        if self.search_by_isbn(isbn):
            logging.warning("Book with this ISBN already exists.")
            return False

        book = Book(title, author, isbn)
        self.books.append(book)
        logging.info(f"Book added: {book}")
        self.save_to_file()
        return True

    def search_by_title(self, title):
        return [book for book in self.books if title.lower() in book.title.lower()]

    def search_by_isbn(self, isbn):
        for book in self.books:
            if book.isbn == isbn:
                return book
        return None

    def display_all(self):
        return self.books

    # ---------- Issue & Return ----------
    def issue_book(self, isbn):
        book = self.search_by_isbn(isbn)
        if not book:
            return None, "Book not found."

        if book.issue():
            self.save_to_file()
            return book, "Book issued successfully."
        else:
            return book, "Book is already issued."

    def return_book(self, isbn):
        book = self.search_by_isbn(isbn)
        if not book:
            return None, "Book not found."

        if book.return_book():
            self.save_to_file()
            return book, "Book returned successfully."
        else:
            return book, "Book was not issued."